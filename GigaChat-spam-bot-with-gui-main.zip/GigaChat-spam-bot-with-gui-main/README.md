# GigaChat

![](https://media.tenor.com/yPUAJMwL2uwAAAAC/gigachad.gif)


## What is GigaChat
GigaChat is a opensource application for those who does not have motto for their lives and sick of doing daily sh*t, GigaChat 1.0 provides you with a nice looking interface to spam your friend or neighbour's sharma uncle for some reason. 

## Why GigaChat
Duh! Thats what i was supposed to ask, nvm GigaChat looks better than other old school funky junky spam apps.

## Features
- Interval slider
- Custom message
- Uplaod message file directly to input
- Shortcut keys that even works in background or unfocused
- Greatest UI ever on spammer

## How to use

- Step 1: Switch on ur pc
- Step 2: Download project file from this repo
- Step 3: Open up file in Visual Studio
- Step 4: Run build
- Step 5: Enter message
- Step 6: Start spammer with start button

## Use SHIFT + Q to start spammer even in background and SHIFT + E to stop.


And yes i used cracked bunifu plugin so it might require you to install bunifu too if you dont want to... show ur programming skills to remove all bunifu elements (any element with bunifu at start of the name i.e BunifuButton, BunifuSlider) and add default controls instead 


GigaChat is open source timepass project that i created for no reason
